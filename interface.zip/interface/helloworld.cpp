#include <iostream>
#include <netinet/in.h>

int main()
{
	/* code */
	std::cout <<"Hello world!\n";
	return 0;
}